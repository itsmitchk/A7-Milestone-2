
#include <iostream>
#include "functions.h"
#include "bigint/bigint.h"
#include <stdlib.h>
#include <cmath>

// takes filename and returns vec of trigrams
std::vector<int> getVec(std::string filename){
  int first, second, third,index;
  char c,c1,c2,c3,lower;
  std::vector<int> vec(17576,0); // creates vec of zeros
  std::string bigStr;
  std:: ifstream infile;
  infile.open(filename);
  // incase the filename isnt vaild
  if(infile.fail()){
    std::cerr << "functions: "<< filename <<": no such file or directory" << '\n';
 }
 int count =0;
 // gets the first 2 alphabetic letters in file
 while (infile.get(c) and count <2) {
  if(isalpha(c)){
    lower = tolower(c); // makes lowercase
    bigStr += lower;
    count +=1;
    }
  else{
      continue;
    }
  }
  // renames values
  c1 = bigStr[0];
  c2 =bigStr[1];


  while (infile.get(c)) {
    if(isalpha(c)){
      lower = tolower(c);
      c3 = lower;
      }
    else{
        continue;
        }
        // using ASSCI values to get index and +=1
    first = c1 - 97;
    second = c2 - 97;
    third = c3 -97;
    index = (first * 26 * 26) + (second * 26) + third;
    vec[index] +=1;
    //shift the values down 1
    c1 = c2;
    c2 = c3;
    }
  return vec;
}


//prints vector with spaces and ends with a \n
void to_file(std::vector<int> vec){
  std::cout << vec[0];
  for(unsigned long i = 1;i< vec.size();i++){
    std::cout << " ";
    std::cout << vec[i];
  }
  std::cout <<'\n';
}


// Calculates Cos between 2 vectors frequencies
double summation(std::vector<int> vec1, std::vector<int> vec2){
  bigint sum,a ,b;

// summation
  for(unsigned long i=0;i<= vec1.size()-1;i++){
    sum += (vec1[i] * vec2[i]);
    a += (vec1[i] * vec1[i]);
    b += (vec2[i] * vec2[i]);
  }


  sum = (sum * sum) * 1000000; //scaled math
  bigint temp = a*b;
  sum = sum/temp;
  std::string cosineStr = sum.to_string(false); // string of cos value to convert to double
  double cosine = stod(cosineStr);
  cosine = cosine/ 1000000;
  cosine = sqrt(cosine); 
return cosine;
}

//bundles calls into mileSStone 1 into 1 function
void frequencies(std::string filename){
  std::vector<int> tempVec = getVec(filename);
  to_file(tempVec);
}
