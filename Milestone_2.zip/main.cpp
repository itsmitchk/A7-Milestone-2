
#include "bigint/bigint.h"

// takes file name from command line
int main(int argc, char *argv[]) {
   std::vector<int> testing =getVec(argv[argc-1]); // vector of vectors to hold frequencies
   std::vector<std::vector<int>> training;

   //gets frequencies vectors and puts them in training vector
   for(int i = 1; i< argc -1;i++){
      training.push_back(getVec(argv[i]));
   }

   double train, high;
   int index = 0;
   high = summation(training[0],testing);

   // Compares frequencies of languages to testing language and finds highest Cos value and its index
  for(unsigned long i =1; i<= training.size()-1;i++){
      train = summation(training[i],testing);
      if (train > high){
        high = train;
        index = i;
      }
  }
  std::cout << argv[index+ 1] << '\n';
  return 0;
}
