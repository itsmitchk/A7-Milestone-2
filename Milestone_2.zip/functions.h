/**
 * Started by Najib 3/21/18
 **/

#ifndef __FUNCTIONS_H__
#define __FUNCTIONS_H__

///////////////////////////////////////////////////////////////////
// INCLUDES GO HERE
///////////////////////////////////////////////////////////////////
#include "bigint/bigint.h"
#include <iostream>
#include <vector>
#include <string>
#include <fstream>

// headers used in functions.cpp
  std::vector<int> getVec(std::string filename);

  void to_file(std::vector<int> vec);

  double summation(std::vector<int> vec1, std::vector<int> vec2);

  void frequencies(std::string filename);




#endif
